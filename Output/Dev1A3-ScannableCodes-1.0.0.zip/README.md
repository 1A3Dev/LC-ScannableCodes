# ScannableCodes

## Information

This mod makes the ID for turrets, landmines & big doors visible when scanning them and also slightly increases the scan distance of turrets & big doors to make viewing the ID easier.

## Changelog

### 1.0.0

- Initial Release
